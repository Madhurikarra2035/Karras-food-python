from fastapi import APIRouter, FastAPI, Form, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import os

BASE_PATH = os.environ.get("BASE_PATH", "").rstrip("/")

app = FastAPI(title="Karra's Food")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))

static_path = BASE_PATH + "/static" if BASE_PATH else "/static"
app.mount(static_path, StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")


def ctx(**kwargs):
    return {"base": BASE_PATH, **kwargs}


MENU = {
    "Starters": [
        {"name": "Crispy Calamari", "price": "$12", "description": "Lightly fried rings with house-made lemon aioli."},
        {"name": "Bruschetta al Pomodoro", "price": "$9", "description": "Grilled rustic bread, marinated tomatoes, fresh basil, garlic."},
        {"name": "Soup of the Day", "price": "$8", "description": "Chef's daily preparation with seasonal ingredients."},
        {"name": "Chicken Skewers", "price": "$14", "description": "Marinated in yogurt and spices, served with tzatziki."},
    ],
    "Mains": [
        {"name": "Grilled Salmon with Herbs", "price": "$26", "description": "Served over a bed of quinoa and roasted vegetables."},
        {"name": "Spaghetti Carbonara", "price": "$19", "description": "Guanciale, egg yolk, pecorino romano, black pepper."},
        {"name": "Lamb Chops with Rosemary", "price": "$32", "description": "Char-grilled, accompanied by garlic roasted potatoes."},
        {"name": "Mushroom Risotto", "price": "$18", "description": "Arborio rice, wild mushrooms, parmesan, truffle oil."},
        {"name": "Chicken Parmigiana", "price": "$22", "description": "Breaded cutlet, marinara, mozzarella, side of pasta."},
    ],
    "Desserts": [
        {"name": "Tiramisu", "price": "$9", "description": "Classic espresso and mascarpone delight."},
        {"name": "Chocolate Lava Cake", "price": "$10", "description": "Warm center, served with vanilla bean gelato."},
        {"name": "Panna Cotta", "price": "$8", "description": "Silky cream dessert with seasonal berry compote."},
        {"name": "Seasonal Fruit Tart", "price": "$9", "description": "Buttery crust, pastry cream, fresh market fruit."},
    ],
    "Drinks": [
        {"name": "Freshly Squeezed Orange Juice", "price": "$6", "description": ""},
        {"name": "House Lemonade", "price": "$5", "description": ""},
        {"name": "Espresso", "price": "$4", "description": ""},
        {"name": "Cappuccino", "price": "$5", "description": ""},
        {"name": "House Red/White Wine", "price": "$10", "description": "Glass"},
    ],
}

FEATURED_DISHES = [
    {"name": "Spaghetti Carbonara", "price": "$19", "description": "Classic Roman style with guanciale and pecorino.", "image": "signature-dish.png"},
    {"name": "Grilled Salmon with Herbs", "price": "$26", "description": "Fresh caught, seared with Mediterranean herbs and lemon.", "image": None, "placeholder": "Grilled Salmon"},
    {"name": "House Tiramisu", "price": "$9", "description": "Espresso-soaked ladyfingers with rich mascarpone.", "image": None, "placeholder": "Tiramisu"},
]

router = APIRouter()


@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(request, "index.html", ctx(featured_dishes=FEATURED_DISHES, active="home"))


@router.get("/menu", response_class=HTMLResponse)
async def menu(request: Request):
    return templates.TemplateResponse(request, "menu.html", ctx(menu=MENU, active="menu"))


@router.get("/about", response_class=HTMLResponse)
async def about(request: Request):
    return templates.TemplateResponse(request, "about.html", ctx(active="about"))


@router.get("/contact", response_class=HTMLResponse)
async def contact(request: Request):
    return templates.TemplateResponse(request, "contact.html", ctx(active="contact", submitted=False, errors={}, form=None))


@router.post("/contact", response_class=HTMLResponse)
async def contact_submit(
    request: Request,
    name: str = Form(""),
    email: str = Form(""),
    date: str = Form(""),
    time: str = Form(""),
    guests: str = Form(""),
    message: str = Form(""),
):
    errors = {}
    if not name.strip():
        errors["name"] = "Name is required."
    if not email.strip() or "@" not in email:
        errors["email"] = "A valid email is required."
    if not date.strip():
        errors["date"] = "Please select a date."
    if not time.strip():
        errors["time"] = "Please select a time."
    if not guests.strip():
        errors["guests"] = "Number of guests is required."

    form_data = {"name": name, "email": email, "date": date, "time": time, "guests": guests, "message": message}

    if errors:
        return templates.TemplateResponse(request, "contact.html", ctx(active="contact", submitted=False, errors=errors, form=form_data))

    return templates.TemplateResponse(request, "contact.html", ctx(active="contact", submitted=True, errors={}, form=None))


app.include_router(router, prefix=BASE_PATH)


if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=True)
