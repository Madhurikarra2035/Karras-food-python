// Navbar scroll behaviour
const navbar = document.getElementById("navbar");
const hamburger = document.getElementById("hamburger");
const navLinks = document.getElementById("navLinks");

if (navbar) {
  const solidPages = ["/menu", "/about", "/contact"];
  const isSolid = solidPages.some(p => window.location.pathname.startsWith(p));
  if (isSolid) {
    navbar.classList.add("navbar--solid");
  }

  window.addEventListener("scroll", () => {
    if (window.scrollY > 60) {
      navbar.classList.add("scrolled");
    } else if (!isSolid) {
      navbar.classList.remove("scrolled");
    }
  });
}

// Mobile menu toggle
if (hamburger && navLinks) {
  hamburger.addEventListener("click", () => {
    hamburger.classList.toggle("active");
    navLinks.classList.toggle("open");
  });
  navLinks.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => {
      hamburger.classList.remove("active");
      navLinks.classList.remove("open");
    });
  });
}

// Scroll-reveal
const reveals = document.querySelectorAll(".reveal");
const observer = new IntersectionObserver(
  entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.12, rootMargin: "0px 0px -60px 0px" }
);
reveals.forEach(el => observer.observe(el));
